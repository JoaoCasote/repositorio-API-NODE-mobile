const User = require('./user');

class UserRepository{
    async createUser (user){
        return await User.create(user);
    }

    async findByUserName(username) {
        return await User.findOne({where: {username}})
    }

    async findall(){
        return await User.findAll();
    }
}

module.exports = new UserRepository();
