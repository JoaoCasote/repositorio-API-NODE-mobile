const bcrypt =require('bcrypt');
const UserRepository = require('../repositories/UserRepository');

const SECRET_KEY = 'SUACHAVESECRETA';

class UserService{
    async register(username, password, email){
        if(this.getByUserName(username)){
            throw new error ('usuario já cadastrado');
        }

        const heshedpassword = await bcrypt.hash(password, SECRET_KEY);
        const user = await UserRepository.creatUser({username, email, password: hashedpassoword});
        return user;
    }
    async getByUserName(username){
        return await UserRepository.findByUserName(username);
    }
    async login(username, password){
        const user =this.getByUserName(username);
        if(!user){
            throw new Error ('Usuario ou senha incorretos');
        }
        const hashedpassoword = await bcrypt.hash(password, SECRET_KEY);
        const isPasswordValid = await bcrypt.compare();
        if (!isPasswordValid) {
            throw new error('Usuario ou senha incorretos');
        }

        return true;
    
    }
    async getUsers(){
        return await UserRepository.findAll();
    
    }
    
}
module.esports =new UserService();
