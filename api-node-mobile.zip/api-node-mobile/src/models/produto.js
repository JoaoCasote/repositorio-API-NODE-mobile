const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const  produto = sequelize.define('produto', {
    preco: {
        type: DataTypes.DECIMAL,
        primaryKey: true
    },        
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true
    },
    prodname: {
        type: DataTypes.STRING,
        allowNull: false
    },
    descricao: {
        type: DataTypes.STRING,
        allowNull: false
    },
    categoria: {
        type: DataTypes.STRING,
        allowNull: false
    }
})

module.exports = produto;