const Produto = require('../models/produto');

class ProdutoRepository{
    async createProduct(produto){
        return await Produto.create(produto);
    }

    async findByProductName(prodname){
        return await Produto.findOne({where: {prodname}})
    }

    async findAll(){
        return await Produto.findAll();
    }
}

module.exports = new ProdutoRepository();