const express = require('express');
const userController = require('./controllers/userController');
const produtoController = require('./controllers/produtoController');

const app = express();

// Middleware para interpretar JSON
app.use(express.json());

// Rotas
app.use('/api/users', userController);
app.use('/api/produtos', produtoController);

// Inicia o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
