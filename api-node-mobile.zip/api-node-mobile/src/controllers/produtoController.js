const express = require('express');
const produtoService = require('../services/produtoService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

// Rota para obter todos os produtos (autenticado)
router.get('/', authenticateToken, async (req, res) => {
    try {
        const produtos = await produtoService.getProducts();
        res.json(produtos);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Rota para cadastrar um novo produto
router.post('/', async (req, res) => {
    try {
        const { prodname, descricao, categoria, preco } = req.body;
        const produto = await produtoService.register(prodname, descricao, categoria, preco);
        res.status(201).json(produto);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;
