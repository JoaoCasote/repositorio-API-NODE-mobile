const produtoRepository = require('../repositories/produtoRepository');
const { v4: UUIDV4 } = require('uuid');

class ProdutoService {
    async register(prodname, descricao, categoria, preco) {
        // Definição dos limites de caracteres
        const LIMITS = {
            prodname: { min: 10, max: 60 },
            descricao: { min: 10, max: 500 },
            categoria: { min: 10, max: 30 }
        };

        // Validação de `prodname`
        if (!prodname || prodname.length < LIMITS.prodname.min || prodname.length > LIMITS.prodname.max) {
            throw new Error(`O nome do produto deve ter entre ${LIMITS.prodname.min} e ${LIMITS.prodname.max} caracteres.`);
        }

        // Validação de `descricao`
        if (!descricao || descricao.length < LIMITS.descricao.min || descricao.length > LIMITS.descricao.max) {
            throw new Error(`A descrição deve ter entre ${LIMITS.descricao.min} e ${LIMITS.descricao.max} caracteres.`);
        }

        // Validação de `categoria`
        if (!categoria || categoria.length < LIMITS.categoria.min || categoria.length > LIMITS.categoria.max) {
            throw new Error(`A categoria deve ter entre ${LIMITS.categoria.min} e ${LIMITS.categoria.max} caracteres.`);
        }

        // Verifica se o produto já existe
        const existingProduct = await this.getByProductName(prodname);
        if (existingProduct) {
            throw new Error('Produto já cadastrado');
        }

        // Cria o produto no banco de dados
        const product = await produtoRepository.createProduct({
            id: UUIDV4(),
            prodname,
            descricao,
            categoria,
            preco
        });

        return product;
    }

    async getByProductName(prodname) {
        return await produtoRepository.findByProductName(prodname);
    }

    async getProducts() {
        return await produtoRepository.findAll();
    }
}

module.exports = new ProdutoService();
